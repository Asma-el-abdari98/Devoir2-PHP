<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Validation de la date</h1>
	<?php
		$jour = $_POST["jour"];
		$mois = $_POST["mois"];
		$year = $_POST["annee"];

		echo "La date saisie est : ".$jour."/".$mois."/".$year."<br>";

		if (checkdate($mois,$jour,$year))		
			echo "La date saisie ".'<span style="color:green;">est valide</span>';
		 elseif($mois == 2)
		 	echo "L'annee ".$year." est non bissextile : ".'<span style="color:red;">Date ivalide</span>';
		 else
		 	echo "La date saisie ".'<span style="color:red;">est non valide</span>';
		
	?>
</body>
</html>