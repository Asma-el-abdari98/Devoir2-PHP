<?php
	function couper($str,$c)
	{
		$Tab=[];
		$ch='';
		for ($i=0; $i <strlen($str) ; $i++) { 
			if ($str[$i] == $c) {
						array_push($Tab,$ch);
						$ch='';
					}
			else
				$ch.=$str[$i];
		}
		array_push($Tab,$ch);
		return $Tab;
	}
	$Tab = couper("Ohayyo hentai",' ');
	for ($i=0; $i <count($Tab) ; $i++) { 
		echo $Tab[$i]."<br>";
	}

?> 