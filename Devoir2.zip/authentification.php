<?php

	$password 	= $_POST['pass'];
	$mail 		= $_POST['email'];
	function login()
	{
		$mail = $_POST['email'];
		if (strpos($mail,".com") !== false) 
		{
			echo "email est ".'<span style="color:green;"><b>valide</b></span><br>';
		}
		else{
			echo "email ".'<span style="color:red;"><b>non valide</b></span><br>';
		}
	}
	function login1()
	{
		$mail = $_POST['email'];
		if (strpos($mail,".com") !== false) 
		{
			return true;
		}
		else{
			return false;
		}
	}

	login();

	function pass(){
		$password 	= $_POST['pass'];
		if (strlen($password) < 8) {
		    echo "Mot de passe trop court !<br>";}


	    $password = $_POST['pass'];
	 
	    if (preg_match('~^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[%$&!?/#@])~', $password)) {
	        echo "Mot de passe ".'<span style="color:green;"><b>est valide</b></span><br>';	
	        return true;}
	    else {echo "Mot de passe ".'<span style="color:red;"><b>est non valide</b></span><br>';
			return false;}
	}
	function pass2(){
	    $password = $_POST['pass'];
	    if (preg_match('~^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[%$&!?/#@])~', $password)) 
	    	{return true;}
	    else {return false;	}
	}

	pass();

	$f=fopen("login.txt","r+");

	while($str=fgets($f)){
				$arr=explode('|',$str);
                foreach ($arr as $k) {
                	echo $k."<br>";
                }
            }

  	if((stristr($str,$mail) == TRUE && stristr($str,$password)) == TRUE)
   	echo "<b>Authentification réussie</b>";

  	elseif(stristr($str,$mail) == TRUE && stristr($str,$password) == FALSE) 
   	echo "<b>Mot de passe invalide</b>";
  
   	else 
   	echo "<b>Login inexistant</b>";
  	

?>