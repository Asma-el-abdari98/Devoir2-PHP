<!DOCTYPE html>
<html>
<head>
	<title>LoGin</title>
	<style type="text/css">
		button
		{
			background-color: aquamarine;
			border:none;
			border-radius: 10px;
		}
		button:hover
		{
			color: white;
			background-color: black;
		}
	</style>
</head>
<form method="POST" action="authentification.php">
	<fieldset style="background-color: #FADA22 ">
		<legend>Ma Formulaire</legend>
		<table>
			<tr>
				<td><label >Email : </label></td>
				<td><input type="email" name="email" placeholder="Your email"></td>
			</tr>
			<tr>
				<td><label>Mot de passe :</label></td>
				<td><input type="password" name="pass" ></td>
			</tr>
			<tr>
				<td>Submit:</td>	
				<td><Button id="sub" type="submit" >Login</td>
			</tr>
		</table>
	
	</fieldset>
</form>
</html>
