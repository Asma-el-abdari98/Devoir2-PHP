<!DOCTYPE html>
<html>
<head>
	<title>exercice</title>
</head>
<body>
	<form method="POST" action="validation.php">
		<h1>Choisir  une date<br></h1>
		<table>
		<tr>
			<td><h3>Jour</h3></td>
			<td><h3>Mois</h3></td>
			<td><h3>Année</h3></td>
		</tr>	
		<tr>
			<td>
				<select name="jour" >
				<?php 
					for ($i=1; $i <=31 ; $i++) 
					{ 
						echo"<option >".$i."</option>";
					}
				?>
				</select>
			</td>
			<td>
				<select name="mois">
				<?php 
					for ($i=1; $i <=12 ; $i++) 
					{ 
						echo"<option >".$i."</option>";
					}
				?>
				</select>
			</td>
			<td>
				<select name="annee">
				<?php 
					for ($i=1900; $i <=2020; $i++) 
					{ 
						echo"<option >".$i."</option>";
					}
				?>
				</select>
			</td>
		</tr>
		</table>
		<button type="submit">Envoyer</button>
	</form>	
</body>
</html>