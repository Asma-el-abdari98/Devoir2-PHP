<?php

	$password 	= $_POST['pass'];
	$mail 		= $_POST['email'];
	function login()
	{
		$mail = $_POST['email'];
		if (strpos($mail,".com") !== false) 
			echo "email est ".'<span style="color:green;"><b>valide</b></span><br>';
		else
			echo "email ".'<span style="color:red;"><b>non valide</b></span><br>';
	}
	function login1()
	{
		$mail = $_POST['email'];
		if (strpos($mail,".com") !== false)
			return true;
		else
			return false;
	}

	login();

	function pass(){
	    $password = $_POST['pass'];
	 	if (strlen($password) < 8) 
		    echo "Mot de passe trop court !<br>";
	    if (preg_match('~^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[%$&!?/#@])~', $password)) 
	        echo "Mot de passe ".'<span style="color:green;"><b>est valide</b></span><br>';	
	    else echo "Mot de passe ".'<span style="color:red;"><b>est non valide</b></span><br>';
	}
	function pass1(){
	    $password = $_POST['pass'];
	    if (strlen($password) < 8) 
		    return false;
	    if (preg_match('~^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[%$&!?/#@])~',$password)) 
	    	return true;
	    else return false;
	}

	pass();
	if (login1() and pass1()) {
		$v = false;
		$f = fopen("login.txt","r");
		$read = fread($f,filesize("login.txt"));
		$lignes = explode("\n",$read);
		for ($i=0; $i < count($lignes); $i++) { 
			$champ = explode("|",$lignes[$i]);
			if ($mail == $champ[0]) {
				$v = true;
				if ($password == $champ[1]) {
					echo "<h3>Authentification réussie</h3><br>";
				}
				else{
					echo "<h3>Mot de passe invalide</h3><br>";
				}
				break;
			}
		}
		if (! $v) {
			echo "<h3>Login inexistant</h3><br>";
		}
        }
    else{
            echo "<h3>Email ou Mot de passe invalide</h3>";
	}
?>
