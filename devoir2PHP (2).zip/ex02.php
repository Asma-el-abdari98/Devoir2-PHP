<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1 align="center">Commendes Clients</h1>
	<table align="center" border="1.5" >
		<tr align="center" bgcolor="#EEE">
			<td>Numero de commande</td>
			<td>Numero Client</td>
			<td>Date de commande</td>
			<td>Designation article</td>
			<td>Quantite (PAL)</td>
			<td>Prix unitaire(HT)</td>
			<td>Date de livraison</td>
			<td>Adresse Client</td>
		</tr>
		<?php
			$f=fopen("Exo2_TP2_Php.txt", 'r+');
			$read=fread($f, filesize("Exo2_TP2_Php.txt"));
			$lignes=explode("\n", $read);
			for ($i=0; $i < count($lignes); $i++) { 
				$champ = explode("@",$lignes[$i]);
			echo "<tr align='newt_centered_window(width, height)'>";
				for ($j=0; $j < count($champ); $j++) { 
					echo "<td>$champ[$j]</td>";
				}
			echo "</tr>";
			}
		?>
	</table>

</body>
</html>